#!/bin/bash

let doble=$1*2

echo "El doble de $1 es $doble"
