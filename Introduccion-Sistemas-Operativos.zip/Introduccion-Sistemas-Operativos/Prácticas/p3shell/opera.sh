#!/bin/bash


let suma=$1+$2
let mul=$1*$2
let res=$1-$2
let div=$1/$2

echo "suma:$suma"
echo "resta:$res"
echo "multiplicacion:$mul"
echo "division:$div"

